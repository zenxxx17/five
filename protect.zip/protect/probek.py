#=========CREATE BEBEK==============#
from linepy import *
from threading import Thread
from datetime import datetime
import pytz
import pafy
import time
import traceback
import random
import multiprocessing
import sys
import json
import codecs
import threading
import glob
import re
import string
import asyncio
import os
import ast
import requests
import subprocess
import tornado
import six
import urllib
import urllib.parse
from time import sleep
from Naked.toolshed.shell import execute_js
mulai = time.time()

cl = LINE('u14d8495b5701eb2e00d95f06c1deecd7:aWF0OiAxNjA3NjI3MDQxNzk0Cg==..wvSk+dDVNz2V4zOc2ROLDwHu0XI=', appName="ANDROIDLITE\t2.16.0\tAndroid OS\t10.18.2")
k1 = LINE('u9e90cd21e0d54b8a9a9f03d087176f43:aWF0OiAxNjA3ODY5MjY3MjU2Cg==..yBPQflh6xi5WmdlZgYFPewE4xZc=', appName="ANDROIDLITE\t2.16.0\tAndroid OS\t10.18.1")
k2 = LINE('u56c88eb5a38bb7b94d36ba93bbf3413b:aWF0OiAxNjA3ODY5NDk4NjYxCg==..//GEU1vtPb4B57P7T7h6r1JWN4o=', appName="ANDROIDLITE\t2.16.0\tAndroid OS\t10.18.0") 
k3 = LINE('u1ca94a1f9687cfec9aba55d4cf56e6bc:aWF0OiAxNjA3ODY5NzU0NzcyCg==..VVLtOCm7Cg5m4LiiwlIcxbjurvM=', appName="ANDROIDLITE\t2.16.0\tAndroid OS\t10.17.9")
k4 = LINE('u5c8cb787279167fadfec384fd46749de:aWF0OiAxNjA3ODcwMTE1NTQ3Cg==..0JJ3f2bRpW6Nl6aoIPjqRsVgJ0g=', appName="ANDROIDLITE\t2.16.0\tAndroid OS\t10.17.8")
k5 = LINE('u9c0e403927e1671497cfc6026bb68edb:aWF0OiAxNjA2NDQ3NjkwMTg2Cg==..exwTAC+J9SECAloBLk66oYIWYck=', appName="ANDROIDLITE\t2.16.0\tAndroid OS\t10.17.7")
k6 = LINE('uc7c71600da8d49ef2590937ece9a85b8:aWF0OiAxNjA2NDQ3MTIwODE5Cg==..7ZPi7UceCfp8ZiLYCUt2CPg0uhU=', appName="ANDROIDLITE\t2.16.0\tAndroid OS\t10.17.6")
k7 = LINE('ucc44d1cc62762f49162a83ed11d09c92:aWF0OiAxNjA2NDYzNjUzNjQxCg==..btt/bEKAutHaxeRea81/4dDsO0Q=', appName="ANDROIDLITE\t2.16.0\tAndroid OS\t10.17.5")
print("DONE LOGIN SUKSES")
#----------------------------------------------------#
poll = OEPoll(cl)
clProfile = cl.getProfile()
clSettings = cl.getSettings()
mid = cl.getProfile().mid
Amid = k1.getProfile().mid
Bmid = k2.getProfile().mid
Cmid = k3.getProfile().mid
Dmid = k4.getProfile().mid
Emid = k5.getProfile().mid
Fmid = k6.getProfile().mid
Gmid = k7.getProfile().mid
rname = "Om "
cpp = {"cpp": False} 

klist = [cl,k1,k2,k3,k4,k5,k6,k7]
Bek = random.choice([cl,k1,k2,k3,k4,k5,k6,k7])
Bebek = random.choice([cl,k1,k2,k3,k4,k5,k6,k7])
Bots = [mid,Amid,Bmid,Cmid,Dmid,Emid,Fmid,Gmid]
Creator = ["u4626589cb09d546f71afa15ff6bcbdf8","ud9be36561eeca01a244755ef3def79ce"]
admin = []
Team = Creator + admin + Bots

proqr = []
proKick= []
pInvite = []
proJoin = []
picon = []
purge = []
proJS = []
pCancl = []
AJS = []
backupJS = []
pname = []
kickBaned = []
kickRead = []
intaPoint = []
msg_dict = []
msg_dict1 = []
targets = []
blacklist = []
event_loop = asyncio.get_event_loop()
kickcount = 0

ban1 = {
    "blacklist":{}
}
Rcancel = {
    "blacklist": {}
}
qr = {
    "blacklist": {}
}
pro = {
    "proqr":{},
    "proKick":{},
    "pInvite":{},
    "proJoin":{},
    "pname":{},
    "picon":{},
    "pro_img":{},
    "pro_name":{},
    "backupJS": {},
    "pCancl":{},
    "purge":{},
    "proJS":{},
    "AJS":{},
    "kickBaned":{},
    "kickRead":{}
}

setting = {
    "admin":{},
    "autoJoinTicket":{},
    "autoJoinTicket":True,
    "addadmin":False,
    "delladmin":False,
    "bots":{},
    "addbots":False,
    "dellbots":False
}

with open("setting.json","r",encoding="utf-8") as fp:set = json.load(fp)
with open('admin.json', 'r') as fp:
    admin = json.load(fp)
with open('bots.json', 'r') as fp:
    Bots = json.load(fp)
with open('ban1.json', 'r') as fp:
    ban = json.load(fp)
with open('pro.json', 'r') as fp:
    blc = json.load(fp)

def banned():
    with open('ban1.json', 'w') as fp:
        json.dump(ban, fp, sort_keys=True, indent=4)
    with open('pro.json', 'w') as fp:
       json.dump(ban, fp, sort_keys=True, indent=4)

def backupData():
    try:
        backup = ban
        backup = Bots
        backup = admin
        backup = set
        f = codecs.open('setting.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except:
        pass 
      
def backupData():
    try:
        backup = ban
        f = codecs.open('ban1.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = Bots
        f = codecs.open('bots.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = admin
        f = codecs.open('admin.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        backup = set
        f = codecs.open('setting.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except:
        pass

def bot(op):
    global kickcount
    try:
        if op.type == 0:
            pass
        else:
            print("[ {} ] {}".format(str(op.type), OpType._VALUES_TO_NAMES[op.type]))
    except:
        pass

def purge(self,to):
    try:
        group = self.client.getGroup(to)
        members = [o.mid for o in group.members]
        ban = set(members).intersection(self.ban["blacklist"])
        cms = "purge.js gid={} token={}".format(to, self.client.authToken)
        for y in ban:
            cms += " uid={}".format(y)
        success = execute_js(cms)
    except:
        e = traceback.format_exc()
        if "code=35" in e:
            print("Kick banned")

def cTime_to_datetime(unixtime):
    return datetime.fromtimestamp(int(str(unixtime)[:len(str(unixtime))-3]))

def dt_to_str(dt):
    return dt.strftime('%H:%M:%S')

def delete_log():
    ndt = datetime.now()
    for data in msg_dict:
        if (datetime.utcnow() - cTime_to_datetime(msg_dict[data]["createdTime"])) > datetime.timedelta(1):
            del msg_dict[msg_id]
    
def restart_program(): 
    python = sys.executable
    os.execl(python, python, * sys.argv)
    
def sendMention(to, mid, firstmessage, lastmessage):
    try:
        arrData = ""
        text = "%s " %(str(firstmessage))
        arr = []
        mention = "@rambu "
        slen = str(len(text))
        elen = str(len(text) + len(mention) - 1)
        arrData = {'S':slen, 'E':elen, 'M':mid}
        arr.append(arrData)
        text += mention + str(lastmessage)
        cl.sendMessage(to, text, {'MENTION': str('{"MENTIONEES":' + json.dumps(arr) + '}')}, 0)
    except Exception as error:
        cl.sendMessage(to, "[ INFO ] Error :\n" + str(error))

def restartBot():
    print ("RESTARTED BOTS")
    backupData()
    time.sleep(1)
    python = sys.executable
    os.execl(python, python, *sys.argv)

def Rkick(grup, target):
    try:
        asd= k1.kickoutFromGroup(grup, [target])
        if asd != None:
            mbutfaild
    except:
        try:
            asd= k2.kickoutFromGroup(grup, [target])
            if asd != None:
                mbutfaild
        except:
            try:
                asd= k3.kickoutFromGroup(grup, [target])
                if asd != None:
                    mbutfaild
            except:
                try:
                    asd= k4.kickoutFromGroup(grup, [target])
                    if asd != None:
                        mbutfaild
                except:
                    try:
                        asd= k7.kickoutFromGroup(grup, [target])
                        if asd != None:
                            mbutfaild
                    except:pass
    print("KICK")
    
def KickRead(grup, target):
    try:
        asd= k1.kickoutFromGroup(grup, [target])
        if asd != None:
            mbutfaild
    except:
        try:
            asd= k2.kickoutFromGroup(grup, [target])
            if asd != None:
                mbutfaild
        except:
            try:
                asd= k3.kickoutFromGroup(grup, [target])
                if asd != None:
                    mbutfaild
            except:
                try:
                    asd= k4.kickoutFromGroup(grup, [target])
                    if asd != None:
                        mbutfaild
                except:
                    try:
                        asd= k7.kickoutFromGroup(grup, [target])
                        if asd != None:
                            mbutfaild
                    except:pass
    print("KICK READ")

def KickBaned(grup, target):
    try:
        asd= k1.kickoutFromGroup(grup, [target])
        if asd != None:
            mbutfaild
    except:
        try:
            asd= k2.kickoutFromGroup(grup, [target])
            if asd != None:
                mbutfaild
        except:
            try:
                asd= k3.kickoutFromGroup(grup, [target])
                if asd != None:
                    mbutfaild
            except:
                try:
                    asd= k4.kickoutFromGroup(grup, [target])
                    if asd != None:
                        mbutfaild
                except:
                    try:
                        asd= k7.kickoutFromGroup(grup, [target])
                        if asd != None:
                            mbutfaild
                    except:pass
    print("KICK BANED")

def ccl(grup, target):
    inv1 = target.split('\x1e')
    for _mid in inv1:
        try:
            asd= k1.cancelGroupInvitation(grup, [_mid])
            if asd != None:
                mbutfaild
        except:
            try:
                asd= k2.cancelGroupInvitation(grup, [_mid])
                if asd != None:
                    mbutfaild
            except:
                try:
                    asd= k3.cancelGroupInvitation(grup, [_mid])
                    if asd != None:
                        mbutfaild
                except:
                    try:
                        asd= k4.cancelGroupInvitation(grup, [_mid])
                        if asd != None:
                            mbutfaild
                    except:
                        try:
                            asd= k7.cancelGroupInvitation(grup, [_mid])
                            if asd != None:
                                mbutfaild
                        except:pass
    print("CANCELL")
    
def Rcancel(grup, target):
    inv1 = target.split('\x1e')
    for _mid in inv1:
        try:
            k1.cancelGroupInvitation(grup,[_mid])
        except:
            try:
                k2.cancelGroupInvitation(grup,[_mid])
            except:
                try:
                    k3.cancelGroupInvitation(grup,[_mid])
                except:
                    try:
                        k4.cancelGroupInvitation(grup,[_mid])
                    except:
                        try:
                            k7.cancelGroupInvitation(grup,[_mid])
                        except:pass
    print("R_CANCEL")       

def backp(grup, target):
    try:
        k1.getCompactGroup(grup)
        k1.inviteIntoGroup(grup, [target])
        k7.acceptGroupInvitation(grup)
        k2.acceptGroupInvitation(grup)
        k3.acceptGroupInvitation(grup)
        k4.acceptGroupInvitation(grup)
    except:
        try:
            k2.getCompactGroup(grup)
            k2.inviteIntoGroup(grup, [target])
            k1.acceptGroupInvitation(grup)
            k3.acceptGroupInvitation(grup)
            k4.acceptGroupInvitation(grup)
            k7.acceptGroupInvitation(grup)
        except:
            try:
                k3.getCompactGroup(grup)
                k3.inviteIntoGroup(grup, [target])
                k4.acceptGroupInvitation(grup)
                k1.acceptGroupInvitation(grup)
                k2.acceptGroupInvitation(grup)
                k7.acceptGroupInvitation(grup)
            except:
                try:
                    k4.getCompactGroup(grup)
                    k4.inviteIntoGroup(grup, [target])
                    k3.acceptGroupInvitation(grup)
                    k1.acceptGroupInvitation(grup)
                    k2.acceptGroupInvitation(grup)
                    k7.acceptGroupInvitation(grup)
                except:
                    try:
                        G = cl.getCompactGroup(grup)
                        G.preventedJoinByTicket = False
                        cl.updateGroup(G)
                        Ticket = cl.reissueGroupTicket(grup)
                        k1.acceptGroupInvitationByTicket(grup,Ticket)
                        k2.acceptGroupInvitationByTicket(grup,Ticket)
                        k3.acceptGroupInvitationByTicket(grup,Ticket)
                        k4.acceptGroupInvitationByTicket(grup,Ticket)
                    except:pass                                      
    print("KICKERS BACKUP 0")

def backp1(grup, target):
    try:
        k2.getCompactGroup(grup)
        k2.inviteIntoGroup(grup, [target])
        k1.acceptGroupInvitation(grup)
        k4.acceptGroupInvitation(grup)
        k3.acceptGroupInvitation(grup)
        k7.acceptGroupInvitation(grup)
    except:
        try:
            k3.getCompactGroup(grup)
            k3.inviteIntoGroup(grup, [target])
            k2.acceptGroupInvitation(grup)
            k1.acceptGroupInvitation(grup)
            k4.acceptGroupInvitation(grup)
            k7.acceptGroupInvitation(grup)
        except:
            try:
                k4.getCompactGroup(grup)
                k4.inviteIntoGroup(grup, [target])
                k3.acceptGroupInvitation(grup)
                k2.acceptGroupInvitation(grup)
                k1.acceptGroupInvitation(grup)
                k7.acceptGroupInvitation(grup)
            except:
                try:
                    k7.getCompactGroup(grup)
                    k7.inviteIntoGroup(grup, [target])
                    k4.acceptGroupInvitation(grup)
                    k1.acceptGroupInvitation(grup)
                    k2.acceptGroupInvitation(grup)
                    k3.acceptGroupInvitation(grup)
                except:pass
    print("KICKERS BACKUP [1]")

def backp2(grup, target):
    try:
        k3.getCompactGroup(grup)
        k3.inviteIntoGroup(grup, [target])
        k7.acceptGroupInvitation(grup)
        k1.acceptGroupInvitation(grup)
        k4.acceptGroupInvitation(grup)
        k2.acceptGroupInvitation(grup)
    except:
        try:
            k4.getCompactGroup(grup)
            k4.inviteIntoGroup(grup, [target])
            k3.acceptGroupInvitation(grup)
            k1.acceptGroupInvitation(grup)
            k2.acceptGroupInvitation(grup)          
            k7.acceptGroupInvitation(grup)
        except:
            try:
                k7.getCompactGroup(grup)
                k7.inviteIntoGroup(grup, [target])
                k1.acceptGroupInvitation(grup)
                k4.acceptGroupInvitation(grup)
                k2.acceptGroupInvitation(grup)
                k3.acceptGroupInvitation(grup)
            except:
                try:
                    k1.getCompactGroup(grup)
                    k1.inviteIntoGroup(grup, [target])
                    k7.acceptGroupInvitation(grup)
                    k2.acceptGroupInvitation(grup)
                    k3.acceptGroupInvitation(grup)
                    k4.acceptGroupInvitation(grup)
                except:pass
    print("KICKERS BACKUP [2]")    

def backp3(grup, target):
    try:
        k4.getCompactGroup(grup)
        k4.inviteIntoGroup(grup, [target])
        k1.bacceptGroupInvitation(grup)
        k3.acceptGroupInvitation(grup)
        k2.acceptGroupInvitation(grup)
        k7.acceptGroupInvitation(grup)
    except:
        try:
            k7.getCompactGroup(grup)
            k7.inviteIntoGroup(grup, [target])
            k4.acceptGroupInvitation(grup)
            k1.acceptGroupInvitation(grup)
            k2.acceptGroupInvitation(grup)
            k3.acceptGroupInvitation(grup)
        except:
            try:
                k1.getCompactGroup(grup)
                k1.inviteIntoGroup(grup, [target])
                k2.acceptGroupInvitation(grup)
                k3.acceptGroupInvitation(grup)
                k4.acceptGroupInvitation(grup)
                k7.acceptGroupInvitation(grup)
            except:
                try:
                    k2.getCompactGroup(grup)
                    k2.inviteIntoGroup(grup, [target])
                    k7.acceptGroupInvitation(grup)
                    k1.acceptGroupInvitation(grup)
                    k4.acceptGroupInvitation(grup)
                    k3.acceptGroupInvitation(grup)
                except:pass
    print("KICKERS BACKUP [3]")    

def backp4(grup, target):
    try:
        k7.getCompactGroup(grup)
        k7.inviteIntoGroup(grup, [target])
        k2.acceptGroupInvitation(grup)
        k1.acceptGroupInvitation(grup)
        k3.acceptGroupInvitation(grup)
        k4.acceptGroupInvitation(grup)
    except:
        try:
            k1.getCompactGroup(grup)
            k1.inviteIntoGroup(grup, [target])
            k4.acceptGroupInvitation(grup)
            k3.acceptGroupInvitation(grup)
            k2.acceptGroupInvitation(grup)
            k7.acceptGroupInvitation(grup)
        except:
            try:
                k2.getCompactGroup(grup)
                k2.inviteIntoGroup(grup, [target])
                k3.acceptGroupInvitation(grup)
                k1.acceptGroupInvitation(grup)
                k7.acceptGroupInvitation(grup)
                k4.acceptGroupInvitation(grup)
            except:
                try:
                    k3.getCompactGroup(grup)
                    k3.inviteIntoGroup(grup, [target])
                    k1.acceptGroupInvitation(grup)
                    k2.acceptGroupInvitation(grup)
                    k7.acceptGroupInvitation(grup)
                    k4.acceptGroupInvitation(grup)
                except:pass
    print("KICKERS BACKUP [4]")    

def NOTIFIED_BACKUP_FROM_GROUP(op):
    if op.param3 in Creator:
        if op.param2 in Team:
            pass
        else:
            if op.param2 not in ban["blacklist"]:
                ban["blacklist"][op.param2] = True
                f=codecs.open('ban1.json','w','utf-8')
                json.dump(ban, f, sort_keys=True, indent=4,ensure_ascii=False)
            try:
                k1.findAndAddContactsByMid(op.param3)
                k1.kickoutFromGroup(op.param1,[op.param2])
                k1.inviteIntoGroup(op.param1,[op.param3])
            except:
                try:
                    k2.findAndAddContactsByMid(op.param3)
                    k2.kickoutFromGroup(op.param1,[op.param2])
                    k2.inviteIntoGroup(op.param1,[op.param3])
                except:
                    try:
                        k3.findAndAddContactsByMid(op.param3)
                        k3.kickoutFromGroup(op.param1,[op.param2])
                        k3.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            k4.findAndAddContactsByMid(op.param3)
                            k4.kickoutFromGroup(op.param1,[op.param2])
                            k4.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:                                    
                                k7.findAndAddContactsByMid(op.param3)
                                k7.kickoutFromGroup(op.param1,[op.param2])
                                k7.inviteIntoGroup(op.param1,[op.param3])
                            except:                                        
                                pass
    print("KICKERS BACKUP [ADMIN]") 
    if op.param3 in admin:
        if op.param2 in Team:
            pass
        else:
            if op.param2 not in ban["blacklist"]:
                ban["blacklist"][op.param2] = True
                f=codecs.open('ban1.json','w','utf-8')
                json.dump(ban, f, sort_keys=True, indent=4,ensure_ascii=False)
            try:
                k1.findAndAddContactsByMid(op.param3)
                k1.kickoutFromGroup(op.param1,[op.param2])
                k1.inviteIntoGroup(op.param1,[op.param3])
            except:
                try:
                    k2.findAndAddContactsByMid(op.param3)
                    k2.kickoutFromGroup(op.param1,[op.param2])
                    k2.inviteIntoGroup(op.param1,[op.param3])
                except:
                    try:
                        k3.findAndAddContactsByMid(op.param3)
                        k3.kickoutFromGroup(op.param1,[op.param2])
                        k3.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            k4.findAndAddContactsByMid(op.param3)
                            k4.kickoutFromGroup(op.param1,[op.param2])
                            k4.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:                                    
                                k7.findAndAddContactsByMid(op.param3)
                                k7.kickoutFromGroup(op.param1,[op.param2])
                                k7.inviteIntoGroup(op.param1,[op.param3])
                            except:                                        
                                pass
    print("KICKERS BACKUP [ADMIN]")

def NOTIFIED_KICKOUT_FROM_GROUP(op):
    if op.param1 in pro["proKick"]:
        if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
            ban["blacklist"][op.param2] = True
            try:
                k1.kickoutFromGroup(op.param1,[op.param2])
            except:
                try:
                    k2.kickoutFromGroup(op.param1,[op.param2])
                except:
                    try:
                        k3.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            k4.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                k7.kickoutFromGroup(op.param1,[op.param2])
                            except:
                                pass
    print("PROTECT KICK")
    if op.param1 in pro["proJS"]:
        if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
            if op.param3 in mid and Amid and Bmid and Cmid and Dmid and Emid:
                ban["blacklist"][op.param2] = True
                try:
                    k6.acceptGroupInvitation(op.param1)
                    k6.kickoutFromGroup(op.param1,[op.param2])
                    k6.inviteIntoGroup(op.param1,[mid,Amid,Bmid,Cmid,Dmid])
                    G = cl.getGroup(op.param1)
                    G.preventedJoinByTicket = False
                    cl.updateGroup(G)
                    Ticket = cl.reissueGroupTicket(op.param1)
                    k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                    X = cl.getGroup(op.param1)
                    X.preventedJoinByTicket = True
                    cl.updateGroup(X)
                    k6.leaveGroup(op.param1)
                    cl.inviteIntoGroup(op.param1,[Fmid])
                except:pass
    print("PROTECT ANTIJS")
    if op.param1 in pro["backupJS"]:
        if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
            if op.param3 in Creator and admin:
                ban["blacklist"][op.param2] = True
                try:
                    k6.acceptGroupInvitation(op.param1)
                    k6.kickoutFromGroup(op.param1,[op.param2])
                    k6.inviteIntoGroup(op.param1,[Creator,admin,mid])
                    G = cl.getGroup(op.param1)
                    G.preventedJoinByTicket = False
                    cl.updateGroup(G)
                    Ticket = cl.reissueGroupTicket(op.param1)
                    k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                    X = cl.getGroup(op.param1)
                    X.preventedJoinByTicket = True
                    cl.updateGroup(X)
                    k6.leaveGroup(op.param1)
                    cl.inviteIntoGroup(op.param1,[Fmid])
                except:pass
    print("BACKUP ANTIJS")    
    if op.param1 in pro["proJS"]:
        if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
            if op.param3 in mid and Amid and Bmid and Cmid and Dmid and Fmid:
                ban["blacklist"][op.param2] = True
                try:
                    k5.acceptGroupInvitation(op.param1)
                    k5.kickoutFromGroup(op.param1,[op.param2])
                    k5.inviteIntoGroup(op.param1,[mid,Amid,Bmid,Cmid,Dmid])
                    G = cl.getGroup(op.param1)
                    G.preventedJoinByTicket = False
                    cl.updateGroup(G)
                    Ticket = cl.reissueGroupTicket(op.param1)
                    k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                    X = cl.getGroup(op.param1)
                    X.preventedJoinByTicket = True
                    cl.updateGroup(X)
                    k5.leaveGroup(op.param1)
                    cl.inviteIntoGroup(op.param1,[Emid])
                except:pass
    print("PROTECT ANTIJS2") 
    if op.param1 in pro["backupJS"]:
        if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
            if op.param3 in Creator and admin:
                ban["blacklist"][op.param2] = True
                try:
                    k5.acceptGroupInvitation(op.param1)
                    k5.kickoutFromGroup(op.param1,[op.param2])
                    k5.inviteIntoGroup(op.param1,[Creator,admin,mid])
                    G = cl.getGroup(op.param1)
                    G.preventedJoinByTicket = False
                    cl.updateGroup(G)
                    Ticket = cl.reissueGroupTicket(op.param1)
                    k1.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k2.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k3.acceptGroupInvitationByTicket(op.param1,Ticket)
                    k4.acceptGroupInvitationByTicket(op.param1,Ticket)
                    X = cl.getGroup(op.param1)
                    X.preventedJoinByTicket = True
                    cl.updateGroup(X)
                    k5.leaveGroup(op.param1)
                    cl.inviteIntoGroup(op.param1,[Emid])
                except:pass
    print("BACKUP ANTIJS2")
    
def NOTIFIED_BACKUP_AJS(op):
    if op.param1 in pro["AJS"]:           
        if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
            if op.param3 in Emid:
                ban["blacklist"][op.param2] = True
                try:
                    k6.acceptGroupInvitation(op.param1)
                    k6.kickoutFromGroup(op.param1,[op.param2])
                    k6.inviteIntoGroup(op.param1,[Emid])
                    k6.leaveGroup(op.param1)
                    cl.inviteIntoGroup(op.param1,[Fmid])
                except:pass
    print("BACKUP ANTIJS")
    if op.param1 in pro["AJS"]:           
        if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
            if op.param3 in Fmid:
                ban["blacklist"][op.param2] = True
                try:
                    k5.acceptGroupInvitation(op.param1)
                    k5.kickoutFromGroup(op.param1,[op.param2])
                    k5.inviteIntoGroup(op.param1,[Fmid])
                    k5.leaveGroup(op.param1)
                    cl.inviteIntoGroup(op.param1,[Emid])
                except:pass
    print("BACKUP ANTIJS2")

def NOTIFIED_INVITE_INTO_GROUP(op):
    if op.type == 13 or op.type == 124:
        if op.param1 in pro["pInvite"]:
            if op.param2 in Bots or op.param2 in Creator or op.param2 in admin:pass
            else:
                try:
                    if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                        k1.cancelGroupInvitation(op.param1,[op.param3])
                        k1.kickoutFromGroup(op.param1,[op.param2])
                        ban["blacklist"][op.param2] = True
                except:
                    try:
                        if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                            k2.cancelGroupInvitation(op.param1,[op.param3])
                            k2.kickoutFromGroup(op.param1,[op.param2])
                            ban["blacklist"][op.param2] = True
                    except:
                        try:
                            if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                                k3.cancelGroupInvitation(op.param1,[op.param3])
                                k3.kickoutFromGroup(op.param1,[op.param2])
                                ban["blacklist"][op.param2] = True
                        except:
                            try:
                                if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                                    k4.cancelGroupInvitation(op.param1,[op.param3])
                                    k4.kickoutFromGroup(op.param1,[op.param2])
                                    ban["blacklist"][op.param2] = True
                            except:
                                try:
                                    if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                                        k7.cancelGroupInvitation(op.param1,[op.param3])
                                        k7.kickoutFromGroup(op.param1,[op.param2])
                                        ban["blacklist"][op.param2] = True
                                except:pass 
    print("PROTECT INVITE")
    
def NOTIFIED_KICKJOIN_GROUP(op):
    if op.type == 17 or op.type == 130:
        if op.param1 in pro["proJoin"]:
            if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                ban["blacklist"][op.param2] = True
                try:
                    Bebek.kickoutFromGroup(op.param1,[op.param2])
                except:
                    try:
                        Bebek.kickoutFromGroup(op.param1,[op.param2])
                    except:
                        pass
    print("PRO JOIN")
    
def NOTIFIED_UPDATE_GROUP(op):
    if op.type == 11 or op.type == 122:
        if op.param1 in pro["proqr"]:
            if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                X = cl.getGroup(op.param1)
                X.preventedJoinByTicket = True
                Bebek.kickoutFromGroup(op.param1,[op.param2])            
                ban["blacklist"][op.param2] = True
                cl.updateGroup(X)
    print("PROTECT LINK GROUP")       
    if op.type == 11 or op.type == 122:
        if op.param3 == '1':
            if op.param1 in pro['pname']:
                if op.param2 in Bots and op.param2 in Creator and op.param2 in admin:
                    pass
                else:
                    try:
                        G = cl.getGroup(op.param1)
                    except:
                        try:
                            G = cl.getGroup(op.param1)
                        except:
                            try:
                                G = cl.getGroup(op.param1)
                            except:pass
                    G.name = pro['pro_name'][op.param1]
                    try:
                        cl.updateGroup(G)
                    except:
                        try:
                            cl.updateGroup(G)
                        except:
                            try:
                                cl.updateGroup(G)
                            except:pass
                    if op.param2 in Bots and op.param2 in Creator and op.param2 in admin:
                        pass
                    else:
                        ban['blacklist'][op.param2] = True
                        try:
                            Bebek.kickoutFromGroup(op.param1,[op.param2])
                        except:
                            try:
                                k7.kickoutFromGroup(op.param1,[op.param2])
                            except:pass

    if op.type == 11 or op.type == 122:
        if op.param1 in pro['picon']:
            if op.param3 == '2':
                if op.param2 in Bots and op.param2 in Creator and op.param2 in admin:
                    pass
                else:
                    try:
                        admin = pro["pro_img"][op.param1]
                        cl.updateGroupPicture(op.param1,admin)
                        Bebek.kickoutFromGroup(op.param1,[op.param2])
                        targets = [op.param2]
                        for target in targets:
                            if target in ban["blacklist"]:
                                pass
                            else:
                                ban['blacklist'][op.param2] = True
                    except:pass    
    print("PROTECT IMG GROUP")
    
def backpAJS(grup, target): 
    try:
        k7.getCompactGroup(grup)
        k7.inviteIntoGroup(grup, [target])
    except:
        try:
            k1.getCompactGroup(grup)
            k1.inviteIntoGroup(grup, [target])
        except:
            try:
                k2.getCompactGroup(grup)
                k2.inviteIntoGroup(grup, [target])
            except:
                try:
                    k3.getCompactGroup(grup)
                    k3.inviteIntoGroup(grup, [target])
                except:
                    try:
                        k4.getCompactGroup(grup)
                        k4.inviteIntoGroup(grup, [target])
                    except:
                        pass
    print("KICKERS BACKUP [AJS]") 
    
def backpAJS1(grup, target): 
    try:
        k7.getCompactGroup(grup)
        k7.inviteIntoGroup(grup, [target])
    except:
        try:
            k1.getCompactGroup(grup)
            k1.inviteIntoGroup(grup, [target])
        except:
            try:
                k2.getCompactGroup(grup)
                k2.inviteIntoGroup(grup, [target])
            except:
                try:
                    k3.getCompactGroup(grup)
                    k3.inviteIntoGroup(grup, [target])
                except:
                    try:
                        k4.getCompactGroup(grup)
                        k4.inviteIntoGroup(grup, [target])
                    except:
                        pass
    print("KICKERS BACKUP [AJS2]") 
    
def purge(grup, target):
    try:
        asd= k1.kickoutFromGroup(grup, [target])
        if asd != None:
            mbutfaild
    except:
        try:
            asd= k2.kickoutFromGroup(grup, [target])
            if asd != None:
                mbutfaild
        except:
            try:
                asd= k3.kickoutFromGroup(grup, [target])
                if asd != None:
                    mbutfaild
            except:
                try:
                    asd= k4.kickoutFromGroup(grup, [target])
                    if asd != None:
                        mbutfaild
                except:
                    try:
                        asd= k7.kickoutFromGroup(grup, [target])
                        if asd != None:
                            mbutfaild
                    except:pass
                    
    print("AUTO PURGE [13]") 

def NOTIFIED_REJECT_GROUP_INVITATION(op):
    if op.param1 in pro["pCancl"]:
        if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
            ban["blacklist"][op.param2] = True
            try:
                k7.findAndAddContactsByMid(op.param3)
                k7.kickoutFromGroup(op.param1,[op.param2])
                k7.inviteIntoGroup(op.param1,[op.param3])
            except:
                try:
                    k1.findAndAddContactsByMid(op.param3)
                    k1.kickoutFromGroup(op.param1,[op.param2])
                    k1.inviteIntoGroup(op.param1,[op.param3])
                except:
                    try:
                        k2.findAndAddContactsByMid(op.param3)
                        k2.kickoutFromGroup(op.param1,[op.param2])
                        k2.inviteIntoGroup(op.param1,[op.param3])
                    except:
                        try:
                            k3.findAndAddContactsByMid(op.param3)
                            k3.kickoutFromGroup(op.param1,[op.param2])
                            k3.inviteIntoGroup(op.param1,[op.param3])
                        except:
                            try:
                                k4.findAndAddContactsByMid(op.param3)
                                k4.kickoutFromGroup(op.param1,[op.param2])
                                k4.inviteIntoGroup(op.param1,[op.param3])
                            except:
                                pass
    print("PROTECT CANCELL")
    
def lockqr(grup):
    try:
        G = k1.getGroup(grup)
        G.preventedJoinByTicket = True
        k1.updateGroup(G)
    except:
        try:
            G = k2.getGroup(grup)
            G.preventedJoinByTicket = True
            k2.updateGroup(G)
        except:
            try:
                G = k3.getGroup(grup)
                G.preventedJoinByTicket = True
                k3.updateGroup(G)
            except:
                try:
                    G = k4.getGroup(grup)
                    G.preventedJoinByTicket = True
                    k4.updateGroup(G)
                except:
                    try:
                        G = k7.getGroup(grup)
                        G.preventedJoinByTicket = True
                        k7.updateGroup(G)
                    except:
                        pass
    print("BL QR")
#=========================DEFF PURGE=========================================#
    if op.type == 18 or op.type == 124:
        kickcount += 1
    if op.type == 17 or op.type == 13 or op.type == 124 or op.type == 130:
        if op.param2 in pro["purge"]:
            G = cl.getGroup(op.param1)
            if G is None:
                pass
            else:
                gMembMids = [contact.mid for contact in G.members]
                matched_list = []
                for tag in ban['blacklist']:
                    matched_list+=filter(lambda str: str == tag, gMembMids)
                if matched_list == []:
                    return
                for jj in matched_list:
                    try:
                        klist = [k7,k1,k2,k3,k4]
                        kickers = random.choice(klist)
                        kickers.kickoutFromGroup(op.param2,[jj])
                    except:
                        pass

        if op.param2 in ban['blacklist']:
            if op.param2 in Bots:
                pass
            elif op.param2 in Team:
                pass
            else:
                try:
                    klist=[k7,k1,k2,k3,k4]
                    kicker=random.choice(klist)
                    group = kicker.getGroup(op.param1)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in ban['blacklist']:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        return
                    for jj in matched_list:
                        klist=[k7,k1,k2,k3,k4]
                        kicked=random.choice(klist)
                        kicked.kickoutFromGroup(op.param2,[jj])
                except:
                    pass
    print("KICK BL_PURGE")

def proqr(grup):
    if grup in pro["proqr"]:
        try:
            G = k1.getGroup(grup)
            G.preventedJoinByTicket = True
            k1.updateGroup(G)
        except:
            try:
                G = k2.getGroup(grup)
                G.preventedJoinByTicket = True
                k2.updateGroup(G)
            except:
                try:
                    G = k3.getGroup(grup)
                    G.preventedJoinByTicket = True
                    k3.updateGroup(G)
                except:
                    try:
                        G = k4.getGroup(grup)
                        G.preventedJoinByTicket = True
                        k4.updateGroup(G)
                    except:
                        try:
                            G = k7.getGroup(grup)
                            G.preventedJoinByTicket = True
                            k7.updateGroup(G)
                        except:
                            pass
    print("PRO QR")  

def pInvite(grup, target):     
    if grup in pro["pInvite"]:        
        inv1 = target.split('\x1e')
        for _mid in inv1:
            try:
                k1.kickoutFromGroup(grup, [target])
                k1.cancelGroupInvitation(grup,[_mid])
            except:
                try:
                    k2.kickoutFromGroup(grup, [target])
                    k2.cancelGroupInvitation(grup,[_mid])
                except:
                    try:
                        k3.kickoutFromGroup(grup, [target])
                        k3.cancelGroupInvitation(grup,[_mid])
                    except:
                        try:
                            k4.kickoutFromGroup(grup, [target])
                            k4.cancelGroupInvitation(grup,[_mid])
                        except:
                            try:
                                k7.kickoutFromGroup(grup, [target])
                                k7.cancelGroupInvitation(grup,[_mid])
                            except:pass
    
def proJoin(grup, target):
    if grup in pro["proJoin"]:
        try:
            if target in ban["blacklist"]:
               k1.kickoutFromGroup(grup, [target])
        except:
            try:
                if target in ban["blacklist"]:
                   k2.kickoutFromGroup(grup, [target])
            except:
                try:
                    if target in ban["blacklist"]:
                       k3.kickoutFromGroup(grup, [target])
                except:
                    try:
                        if target in ban["blacklist"]:
                           k4.kickoutFromGroup(grup, [target])
                    except:
                        try:
                            if target in ban["blacklist"]:
                               k7.kickoutFromGroup(grup, [target])
                        except:
                            pass
    print("PRO JOIN")
    
def proKick(grup, target):
    if grup in pro["proKick"]:
        try:
            k1.kickoutFromGroup(grup, [target])
        except:
            try:
                k2.kickoutFromGroup(grup, [target])
            except:
                try:
                    k3.kickoutFromGroup(grup, [target])
                except:
                    try:
                        k4.kickoutFromGroup(grup, [target])
                    except:
                        try:
                            k7.kickoutFromGroup(grup, [target])
                        except:
                            pass
    print("PRO KICK")
    
def proPurge(grup, target):
    if grup in pro["purge"]:
        try:
            k1.kickoutFromGroup(grup, [target])
        except:
            try:
                k2.kickoutFromGroup(grup, [target])
            except:
                try:
                    k3.kickoutFromGroup(grup, [target])
                except:
                    try:
                        k4.kickoutFromGroup(grup, [target])
                    except:
                        try:
                            k7.kickoutFromGroup(grup, [target])
                        except:
                            pass
    print("AUTO_PURGE")  

def kickRead(grup, target):
    if grup in pro["kickRead"]:
        try:
            k1.kickoutFromGroup(grup, [target])
        except:
            try:
                k2.kickoutFromGroup(grup, [target])
            except:
                try:
                    k3.kickoutFromGroup(grup, [target])
                except:
                    try:
                        k4.kickoutFromGroup(grup, [target])
                    except:
                        try:
                            k7.kickoutFromGroup(grup, [target])
                        except:
                            pass
    print("KICK_READ")

def kickBaned(grup, target):
    if grup in pro["kickBaned"]:
        try:
            k1.kickoutFromGroup(grup, [target])
        except:
            try:
                k2.kickoutFromGroup(grup, [target])
            except:
                try:
                    k3.kickoutFromGroup(grup, [target])
                except:
                    try:
                        k4.kickoutFromGroup(grup, [target])
                    except:
                        try:
                            k7.kickoutFromGroup(grup, [target])
                        except:
                            pass
    print("KICK_BANED")
#=========================DEFF PRO=========================================#
def save_set():
    with open('setting.json','w',encoding='utf-8') as fp:
        return json.dump(set, fp, sort_keys=False, indent=4)

def black(target):
    if target not in ban["blacklist"]:
        ban["blacklist"][target] = True
        banned()

def command(text):
    msg = text.lower()
    if set["response"]["rname"] != "":
        if msg.startswith(set["response"]["rname"]):
            cmd = msg.replace(set["response"]["rname"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd

def RECEIVED_MESSAGE(op):
    global time
    global ast
    global groupParam
    global opType
    global opMsg
    rname = set["response"]["rname"]
    msg = op.message
    text = msg.text
    msg_id = msg.id
    receiver = msg.to
    sender = msg._from
    if msg.toType == 0 or msg.toType == 1 or msg.toType == 2:
        if msg.toType == 0:
            if sender != cl.profile.mid:to = sender
            else:to = receiver
        if msg.toType == 1:to = receiver
        if msg.toType == 2:to = receiver
        if msg.contentType == 0:
            if text is None:return
            else:
                silent = False
                cmds = command(text)
                cmd = " ".join(cmds.split())
            for cmd in cmds.split(' & '):
                if sender in Creator + admin:
                    if text.lower() in ["response"]:
                        k7.sendMessage(to, "A")
                        k1.sendMessage(to, "B")
                        k2.sendMessage(to, "C")
                        k3.sendMessage(to, "D")
                        k4.sendMessage(to, "Semua Udah Hadir Boss\nSiap Protect Group\nAman Gak Aman Yang Penting Anu")

                    if to in set["response"]["chatbot"]:
                        if cmd == "bot on":
                            set["response"]["chatbot"].remove(to)
                            save_set()
                            cl.sendMessage(to, "Bot Ready Enable")
                    if to not in set["response"]["chatbot"]:
                        if cmd == "bot off":
                           if to not in set["response"]["chatbot"]:
                              set["response"]["chatbot"].append(to)
                              save_set()
                              cl.sendMessage(to, "Bot Ready Desable")

                        if cmd == "respon":
                         if sender in Creator + admin:
                            cl.sendMessage(to, "A")
                            k1.sendMessage(to, "B")
                            k2.sendMessage(to, "C")
                            k3.sendMessage(to, "D")
                            k4.sendMessage(to, "🦆")

                        if cmd.startswith("kick"): 
                         if sender in Creator + admin:
                           key = eval(msg.contentMetadata["MENTION"])
                           key["MENTIONEES"][0]["M"]
                           targets = []
                           for x in key["MENTIONEES"]:
                               targets.append(x["M"])
                           for target in targets:
                               if target in Bots:
                                   pass
                               else:
                                   try:
                                       ban["blacklist"][target] = True
                                       klist = [k1,k2,k3,k7,k4]
                                       kicker = random.choice(klist)
                                       kicker.kickoutFromGroup(msg.to,[target])
                                   except:
                                       klist = [k1,k2,k3,k7,k4]
                                       kicker = random.choice(klist)
                                       kicker.sendMessage(msg.to,"Sick")

                        if "!kick " in msg.text:
                          if sender in Creator + admin:
                              nk0 = msg.text.replace("!kick ","")
                              nk1 = nk0.lstrip()
                              nk2 = nk1.replace("@","")
                              nk3 = nk2.rstrip()
                              _name = nk3
                              gs = cl.getGroup(msg.to)
                              targets = []
                              for g in gs.members:
                                  if _name in g.displayName:
                                     targets.append(g.mid)
                              if targets == []:
                                  pass
                              else:
                                  for target in targets:
                                     try:
                                         klist=[k7,k1,k2,k3,k4]
                                         kicker=random.choice(klist)
                                         kicker.kickoutFromGroup(msg.to,[target])
                                         print (msg.to,[g.mid])
                                     except:
                                         pass
                        
                        if cmd.startswith("/name: "):
                          if sender in Creator + admin:
                                  separate = msg.text.split(" ")
                                  string = msg.text.replace(separate[0] + " ","")
                                  if len(string) <= 10000000000:
                                      profile = cl.getProfile()
                                      profile.displayName = string
                                      cl.updateProfile(profile)
                                      cl.sendMessage(msg.to,"Succes " + string + "")

                        if cmd.startswith("/name1: "):
                          if sender in Creator + admin:
                                  separate = msg.text.split(" ")
                                  string = msg.text.replace(separate[0] + " ","")
                                  if len(string) <= 10000000000:
                                      profile = k1.getProfile()
                                      profile.displayName = string
                                      k1.updateProfile(profile)
                                      k1.sendMessage(msg.to,"Succes " + string + "")

                        if cmd.startswith("/name2: "):
                          if sender in Creator + admin:
                                  separate = msg.text.split(" ")
                                  string = msg.text.replace(separate[0] + " ","")
                                  if len(string) <= 10000000000:
                                      profile = k2.getProfile()
                                      profile.displayName = string
                                      k2.updateProfile(profile)
                                      k2.sendMessage(msg.to,"Succes " + string + "")

                        if cmd.startswith("/name3: "):
                          if sender in Creator + admin:
                                  separate = msg.text.split(" ")
                                  string = msg.text.replace(separate[0] + " ","")
                                  if len(string) <= 10000000000:
                                      profile = k3.getProfile()
                                      profile.displayName = string
                                      k3.updateProfile(profile)
                                      k3.sendMessage(msg.to,"Succes " + string + "")

                        if cmd.startswith("/name4: "):
                          if sender in Creator + admin:
                                  separate = msg.text.split(" ")
                                  string = msg.text.replace(separate[0] + " ","")
                                  if len(string) <= 10000000000:
                                      profile = k4.getProfile()
                                      profile.displayName = string
                                      k4.updateProfile(profile)
                                      k4.sendMessage(msg.to,"Succes " + string + "")

                        if cmd.startswith("/name5: "):
                          if sender in Creator + admin:
                                  separate = msg.text.split(" ")
                                  string = msg.text.replace(separate[0] + " ","")
                                  if len(string) <= 10000000000:
                                      profile = k5.getProfile()
                                      profile.displayName = string
                                      k5.updateProfile(profile)
                                      k5.sendMessage(msg.to,"Succes " + string + "")
                                      
                        if cmd.startswith("/name6: "):
                          if sender in Creator + admin:
                                  separate = msg.text.split(" ")
                                  string = msg.text.replace(separate[0] + " ","")
                                  if len(string) <= 10000000000:
                                      profile = k6.getProfile()
                                      profile.displayName = string
                                      k6.updateProfile(profile)
                                      k6.sendMessage(msg.to,"Succes " + string + "")
                            
                        if cmd.startswith("poff "):
                          if sender in Creator:
                              separate = msg.text.split(" ")
                              number = msg.text.replace(separate[0] + " ","")
                              groups = cl.getGroupIdsJoined()
                              ret_ = ""
                              try:
                                  group = groups[int(number)-1]
                                  ginfo = cl.getGroup(group)
                                  del pro["pname"][group]
                                  del pro["picon"][group]
                                  del pro["proJoin"][group]
                                  del pro["proKick"][group]
                                  del pro["proqr"][group]
                                  del pro["pInvite"][group]
                                  del pro["purge"][group]
                                  del pro["kickRead"][group]
                                  del pro["kickBaned"][group]
                                  del pro["AJS"][group]
                                  del pro["proJS"][group]
                                  del pro["pCancl"][group]
                                  del pro["backupJS"][group]
                                  del pro["pro_name"][group]
                                  del pro["pro_img"][group]
                                  cl.sendMessage(msg.to, "Mode Low Protection Deactive\n"+str(ginfo.name))
                              except:
                                  pass
                                
                        if cmd.startswith("pro "):
                          if sender in Creator:
                              separate = msg.text.split(" ")
                              number = msg.text.replace(separate[0] + " ","")
                              groups = cl.getGroupIdsJoined()
                              ret_ = ""
                              try:
                                  group = groups[int(number)-1]
                                  ginfo = cl.getGroup(group)
                                  pro["pname"][group] = True
                                  pro["picon"][group] = True
                                  pro["proJoin"][group] = True
                                  pro["kickBaned"][group] = True
                                  pro["kickRead"][group] = True
                                  pro["proKick"][group] = True
                                  pro["proqr"][group] = True
                                  pro["pInvite"][group] = True
                                  pro["purge"][group] = True
                                  pro["proJS"][group] = True
                                  pro["pCancl"][group] = True
                                  pro["AJS"][group] = True
                                  pro["backupJS"][group] = True
                                  pro["pro_name"][group] = True
                                  pro["pro_img"][group] = True
                                  cl.sendMessage(msg.to, "Mode Hard Protection Deactive\n"+str(ginfo.name))
                              except:
                                  pass
                              
                        if cmd.startswith("pjoin "):
                          if sender in Creator:
                              separate = msg.text.split(" ")
                              number = msg.text.replace(separate[0] + " ","")
                              groups = cl.getGroupIdsJoined()
                              ret_ = ""
                              try:
                                  group = groups[int(number)-1]
                                  ginfo = cl.getGroup(group)
                                  pro["proJoin"][group] = True
                                  cl.sendMessage(msg.to, "Protection Join Group Active\n"+str(ginfo.name))
                              except:
                                  pass
                        if cmd.startswith("pinv "):
                          if sender in Creator:
                              separate = msg.text.split(" ")
                              number = msg.text.replace(separate[0] + " ","")
                              groups = cl.getGroupIdsJoined()
                              ret_ = ""
                              try:
                                  group = groups[int(number)-1]
                                  ginfo = cl.getGroup(group)
                                  pro["pInvite"][group] = True
                                  cl.sendMessage(msg.to, "Protection INVITE Group Active\n"+str(ginfo.name))
                              except:
                                  pass
                        if cmd.startswith("pcancel "):
                          if sender in Creator:
                              separate = msg.text.split(" ")
                              number = msg.text.replace(separate[0] + " ","")
                              groups = cl.getGroupIdsJoined()
                              ret_ = ""
                              try:
                                  group = groups[int(number)-1]
                                  ginfo = cl.getGroup(group)
                                  pro["pCancl"][group] = True
                                  cl.sendMessage(msg.to, "Protection Cancell Group Active\n"+str(ginfo.name))
                              except:
                                  pass                        
                        
                        if cmd.startswith("pqr "):
                          if sender in Creator:
                              separate = msg.text.split(" ")
                              number = msg.text.replace(separate[0] + " ","")
                              groups = cl.getGroupIdsJoined()
                              ret_ = ""
                              try:
                                  group = groups[int(number)-1]
                                  ginfo = cl.getGroup(group)
                                  pro["proqr"][group] = True
                                  cl.sendMessage(msg.to, "Protection QR Group Active\n"+str(ginfo.nane))
                              except:
                                  pass
                        if cmd.startswith("pqroff "):
                          if sender in Creator:
                              separate = msg.text.split(" ")
                              number = msg.text.replace(separate[0] + " ","")
                              groups = cl.getGroupIdsJoined()
                              ret_ = ""
                              try:
                                  group = groups[int(number)-1]
                                  ginfo = cl.getGroup(group)
                                  del pro["proqr"][group]
                                  cl.sendMessage(msg.to, "Protection QR Group Deactive\n"+str(ginfo.name))
                              except:
                                  pass
                        if cmd.startswith("pcanceloff "):
                          if sender in Creator:
                              separate = msg.text.split(" ")
                              number = msg.text.replace(separate[0] + " ","")
                              groups = cl.getGroupIdsJoined()
                              ret_ = ""
                              try:
                                  group = groups[int(number)-1]
                                  ginfo = cl.getGroup(group)
                                  del pro["pCancl"][group]
                                  cl.sendMessage(msg.to, "Protection Cancell Group Deactive\n"+str(ginfo.name))
                              except:
                                  pass                     
                        if cmd.startswith("pinvoff "):
                          if sender in Creator:
                              separate = msg.text.split(" ")
                              number = msg.text.replace(separate[0] + " ","")
                              groups = cl.getGroupIdsJoined()
                              ret_ = ""
                              try:
                                  group = groups[int(number)-1]
                                  ginfo = cl.getGroup(group)
                                  del pro["pInvite"][group]
                                  cl.sendMessage(msg.to, "Protection INVITE Group Deactive\n"+str(ginfo.name))
                              except:
                                  pass                   
                        if cmd.startswith("pjoff "):
                          if sender in Creator:
                              separate = msg.text.split(" ")
                              number = msg.text.replace(separate[0] + " ","")
                              groups = cl.getGroupIdsJoined()
                              ret_ = ""
                              try:
                                  group = groups[int(number)-1]
                                  ginfo = cl.getGroup(group)
                                  del pro["proJoin"][group]
                                  cl.sendMessage(msg.to, "Protection Join Group Deactive\n"+str(ginfo.name))
                              except:
                                  pass
                          
                        if cmd.startswith("left "):
                          if sender in Creator:
                            sep = text.split(" ")
                            query = text.replace(sep[0] + " ","")
                            groups = cl.getGroupIdsJoined()
                            try:
                                listGroup = groups[int(query)-1]
                                group = cl.getGroup(listGroup)
                                cl.leaveGroup(group.id)
                                k1.leaveGroup(group.id)
                                k2.leaveGroup(group.id)
                                k3.leaveGroup(group.id)
                                k4.leaveGroup(group.id)
                                k7.leaveGroup(group.id)
                                cl.sendMessage(msg.to, "Succesfully leave to Group:\n{}".format(group.name))
                            except Exception as error:
                                logError(error)
                                
                        if cmd.startswith('inviteme '):
                          if sender in Creator + admin:
                               text = msg.text.split()
                               number = text[1]
                               if number.isdigit():
                                groups = cl.getGroupIdsJoined()
                                if int(number) < len(groups) and int(number) >= 0:
                                    groupid = groups[int(number)]
                                    group = cl.getGroup(groupid)
                                    target = sender
                                    try:
                                        cl.getGroup(groupid)
                                        cl.findAndAddContactsByMid(target)
                                        cl.inviteIntoGroup(groupid, [target])
                                        cl.sendMessage(msg.to,"Invited to\n " + str(group.name))
                                    except:
                                        cl.sendMessage(msg.to,"I no there baby")
                                        
                        if cmd == "gclist":
                          if sender in Creator + admin:
                                groups = cl.getGroupIdsJoined();txt = "「 Group List 」";num = 1
                                for gid in groups:group = cl.getGroup(gid);txt += "\n%i. %s | ( %s )" % (num, group.name, len(group.members));num += 1
                                cl.sendMessage(to, str(txt))

                        if cmd == "!addbots" and msg._from in Creator:
                            cl.findAndAddContactsByMid(Amid)
                            time.sleep(5)
                            cl.findAndAddContactsByMid(Bmid)
                            time.sleep(5)
                            cl.findAndAddContactsByMid(Cmid)
                            time.sleep(5)
                            cl.findAndAddContactsByMid(Dmid)
                            time.sleep(5)
                            cl.findAndAddContactsByMid(Emid)
                            time.sleep(5)
                            cl.findAndAddContactsByMid(Fmid)
                            time.sleep(5)
                            cl.findAndAddContactsByMid(Gmid)
                            time.sleep(5)
                            cl.sendMessage(to, "Success addbot")
                        if cmd == "!addbots2" and msg._from in Creator:
                            k1.findAndAddContactsByMid(mid)
                            time.sleep(5)
                            k1.findAndAddContactsByMid(Bmid)
                            time.sleep(5)
                            k1.findAndAddContactsByMid(Cmid)
                            time.sleep(5)
                            k1.findAndAddContactsByMid(Dmid)
                            time.sleep(5)
                            k1.findAndAddContactsByMid(Emid)
                            time.sleep(5)
                            k1.findAndAddContactsByMid(Fmid)
                            time.sleep(5)
                            k1.findAndAddContactsByMid(Gmid)
                            time.sleep(5)
                            k1.sendMessage(to, "Success addbot")
                        if cmd == "!addbots3" and msg._from in Creator:
                            k2.findAndAddContactsByMid(mid)
                            time.sleep(5)
                            k2.findAndAddContactsByMid(Amid)
                            time.sleep(5)
                            k2.findAndAddContactsByMid(Cmid)
                            time.sleep(5)
                            k2.findAndAddContactsByMid(Dmid)
                            time.sleep(5)
                            k2.findAndAddContactsByMid(Emid)
                            time.sleep(5)
                            k2.findAndAddContactsByMid(Fmid)
                            time.sleep(5)
                            k2.findAndAddContactsByMid(Gmid)
                            time.sleep(5)
                            k2.sendMessage(to, "Success addbot")
                        if cmd == "!addbots4" and msg._from in Creator:
                            k3.findAndAddContactsByMid(mid)
                            time.sleep(5)
                            k3.findAndAddContactsByMid(Amid)
                            time.sleep(5)
                            k3.findAndAddContactsByMid(Bmid)
                            time.sleep(5)
                            k3.findAndAddContactsByMid(Dmid)
                            time.sleep(5)
                            k3.findAndAddContactsByMid(Emid)
                            time.sleep(5)
                            k3.findAndAddContactsByMid(Fmid)
                            time.sleep(5)
                            k3.findAndAddContactsByMid(Gmid)
                            time.sleep(5)
                            k3.sendMessage(to, "Success addbot")
                        if cmd == "!addbots5" and msg._from in Creator:
                            k4.findAndAddContactsByMid(mid)
                            time.sleep(5)
                            k4.findAndAddContactsByMid(Amid)
                            time.sleep(5)
                            k4.findAndAddContactsByMid(Bmid)
                            time.sleep(5)
                            k4.findAndAddContactsByMid(Cmid)
                            time.sleep(5)
                            k4.findAndAddContactsByMid(Emid)
                            time.sleep(5)
                            k4.findAndAddContactsByMid(Fmid)
                            time.sleep(5)
                            k4.findAndAddContactsByMid(Gmid)
                            time.sleep(5)
                            k4.sendMessage(to, "Success addbot")
                        if cmd == "!addbots6" and msg._from in Creator:
                            k5.findAndAddContactsByMid(mid)
                            time.sleep(5)
                            k5.findAndAddContactsByMid(Amid)
                            time.sleep(5)
                            k5.findAndAddContactsByMid(Bmid)
                            time.sleep(5)
                            k5.findAndAddContactsByMid(Cmid)
                            time.sleep(5)
                            k5.findAndAddContactsByMid(Dmid)
                            time.sleep(5)
                            k5.findAndAddContactsByMid(Fmid)
                            time.sleep(5)
                            k5.findAndAddContactsByMid(Gmid)
                            time.sleep(5)
                            k5.sendMessage(to, "Success addbot")
                        if cmd == "!addbots7" and msg._from in Creator:
                            k6.findAndAddContactsByMid(mid)
                            time.sleep(5)
                            k6.findAndAddContactsByMid(Amid)
                            time.sleep(5)
                            k6.findAndAddContactsByMid(Bmid)
                            time.sleep(5)
                            k6.findAndAddContactsByMid(Cmid)
                            time.sleep(5)
                            k6.findAndAddContactsByMid(Dmid)
                            time.sleep(5)
                            k6.findAndAddContactsByMid(Emid)
                            time.sleep(5)
                            k6.findAndAddContactsByMid(Gmid)
                            time.sleep(5)
                            k6.sendMessage(to, "Success addbot")
                        if cmd == "!addbots8" and msg._from in Creator:
                            k7.findAndAddContactsByMid(mid)
                            time.sleep(5)
                            k7.findAndAddContactsByMid(Amid)
                            time.sleep(5)
                            k7.findAndAddContactsByMid(Bmid)
                            time.sleep(5)
                            k7.findAndAddContactsByMid(Cmid)
                            time.sleep(5)
                            k7.findAndAddContactsByMid(Dmid)
                            time.sleep(5)
                            k7.findAndAddContactsByMid(Emid)
                            time.sleep(5)
                            k7.findAndAddContactsByMid(Fmid)
                            time.sleep(5)
                            k7.sendMessage(to, "Success addbot")
                        if cmd == "bek":
                          if sender in Creator + admin:
                            cl.removeAllMessages(op.param2)
                            k1.removeAllMessages(op.param2)
                            k2.removeAllMessages(op.param2)
                            k3.removeAllMessages(op.param2)
                            k4.removeAllMessages(op.param2)
                            k7.removeAllMessages(op.param2)
                            k5.removeAllMessages(op.param2)
                            k6.removeAllMessages(op.param2)
                            cl.sendMessage(to,"🦆")
                        
                        if cmd == "restart":
                          if sender in Creator:
                            cl.sendMessage(to,"Done Restart")
                            restartBot()

                        if cmd == "cek":
                          if sender in Creator:
                            status = ""
                            try:cl.inviteIntoGroup(to, [cl.profile.mid]);status = "Siap"
                            except:status = "Lemes"
                            try:k1.inviteIntoGroup(to, [k1.profile.mid]);status1 = "Siap"
                            except:status1 = "Lemes"
                            try:k2.inviteIntoGroup(to, [k2.profile.mid]);status2 = "Siap"
                            except:status2 = "Lemes"
                            try:k3.inviteIntoGroup(to, [k3.profile.mid]);status3 = "Siap"
                            except:status3 = "Lemes"
                            try:k4.inviteIntoGroup(to, [k4.profile.mid]);status4 = "Siap"
                            except:status4 = "Lemes"
                            if not silent:cl.sendMessage(to, "✆𝕭𝖊𝖇𝖊𝖐-ᷨ-ͦ-ͭ--ͭ-ͤ-ͣ-ͫ➣\n│➛ Bot: {}\n".format(status)+"│➛ Bot1: {}\n".format(status1)+"│➛ Bot2: {}\n".format(status2)+"│➛ Bot3: {}\n".format(status3)+"│➛ Bot4: {}\n".format(status4)+"「✆𝕭𝖊𝖇𝖊𝖐-ᷨ-ͦ-ͭ--ͭ-ͤ-ͣ-ͫ➣」")

                        if cmd == "!help":
                          if sender in Creator + admin:
                            ret_ = "✆𝕭𝖊𝖇𝖊𝖐-ᷨ-ͦ-ͭ--ͭ-ͤ-ͣ-ͫ➣"
                            ret_ += "\n🦆 ʙᴏᴛ ᴏɴ "
                            ret_ += "\n🦆 ʙᴏᴛ ᴏғғ "
                            ret_ += "\n🦆 ᴊᴇᴘɪᴛ "
                            ret_ += "\n🦆 ɪɴ "
                            ret_ += "\n🦆 ʙᴀʟɪᴋ "
                            ret_ += "\n🦆 !ʙᴀʟɪᴋ "
                            ret_ += "\n🦆 !sᴇᴛ "
                            ret_ += "\n🦆 ᴘʀᴏᴊs "
                            ret_ += "\n🦆 ᴘʀᴏᴊs ʙʏᴇ "
                            ret_ += "\n🦆 ᴊs ʙʏᴇ  "
                            ret_ += "\n🦆 ᴘʀᴏʟɪsᴛ "
                            ret_ += "\n🦆 ᴘʀᴏ ᴏɴ/ᴏғғ "
                            ret_ += "\n🦆 ᴘʀᴏ (ɴᴏ) "
                            ret_ += "\n🦆 ᴘᴏғғ (ɴᴏ) "
                            ret_ += "\n🦆 ᴘᴊᴏɪɴ (ɴᴏ) "
                            ret_ += "\n🦆 ᴘᴊᴏғғ (ɴᴏ) "
                            ret_ += "\n🦆 ᴘϙʀ (ɴᴏ)"
                            ret_ += "\n🦆 ᴘϙʀᴏғғ (ɴᴏ)"
                            ret_ += "\n🦆 ᴘɪɴᴠ (ɴᴏ)"
                            ret_ += "\n🦆 ᴘɪɴᴠᴏғғ (ɴᴏ)"
                            ret_ += "\n🦆 ᴘᴄᴀɴᴄᴇʟ (ɴᴏ)"
                            ret_ += "\n🦆 ᴘᴄᴀɴᴄᴇʟᴏғғ (ɴᴏ)"
                            ret_ += "\n🦆 ʟᴇғᴛ (ɴᴏ) "
                            ret_ += "\n🦆 ɢʟɪsᴛ "
                            ret_ += "\n🦆 ɪɴᴠɪᴛᴇᴍᴇ (ɴᴏ) "
                            ret_ += "\n🦆 ᴀᴅᴍɪɴᴀᴅᴅ @ "
                            ret_ += "\n🦆 ᴀᴅᴍɪɴᴅᴇʟʟ @"
                            ret_ += "\n🦆 ᴀᴅᴍɪɴ "
                            ret_ += "\n🦆 xᴘ "
                            ret_ += "\n🦆 ғʀᴇsʜ  "
                            ret_ += "\n🦆 ғᴛᴏ "
                            ret_ += "\n🦆 /ɴᴀᴍᴇ: (ᴛᴇxᴛ) "
                            ret_ += "\n🦆 ᴀᴅᴅʙᴏᴛ "
                            ret_ += "\n🦆 ʀᴇsᴘᴏɴ "
                            ret_ += "\n🦆 ᴛᴀᴍᴘᴏʟ @"
                            ret_ += "\n🦆 ʙʟ "
                            ret_ += "\n🦆 ɢᴏᴄᴇɴɢ  "
                            ret_ += "\n🦆 ᴄᴇᴋ \n"   
                            ret_ += "✆𝕭𝖊𝖇𝖊𝖐-ᷨ-ͦ-ͭ--ͭ-ͤ-ͣ-ͫ➣"
                            cl.sendMessage(to, str(ret_))
                          
                        if cmd == "!set":
                          if sender in Creator + admin:
                            tz = pytz.timezone("Asia/Jakarta")
                            timeNow = datetime.now(tz=tz)
                            md = "✆𝕭𝖊𝖇𝖊𝖐-ᷨ-ͦ-ͭ--ͭ-ͤ-ͣ-ͫ➣\n"
                            if msg.to in pro["proqr"]: md+="🦆⚫ PʀᴏQr\n"
                            else: md+="🦆⚪ PʀᴏQr\n"
                            if msg.to in pro["proJoin"]: md+="🦆⚫ PʀᴏJᴏɪɴ\n"
                            else: md+="🦆⚪ PʀᴏJᴏɪn\n"
                            if msg.to in pro["proKick"]: md+="🦆⚫ Pro ᴋɪᴄᴋ\n"
                            else: md+="🦆⚪ Pro ᴋɪᴄᴋ\n"
                            if msg.to in pro["pInvite"]: md+="🦆⚫ PʀᴏInvite\n"
                            else: md+="🦆⚪ PʀᴏInvite\n"
                            if msg.to in pro["pname"]: md+="🦆⚫ Pname\n"
                            else: md+="🦆⚪ Pname\n"
                            if msg.to in pro["picon"]: md+="🦆⚫ PʀᴏIcon\n"
                            else: md+="🦆⚪ PʀoIcon\n"
                            if msg.to in pro["pro_name"]: md+="🦆⚫ PʀᴏName\n"
                            else: md+="🦆⚪ PʀᴏName\n"
                            if msg.to in pro["pro_img"]: md+="🦆⚫ PʀᴏImage\n"
                            else: md+="🦆⚪ PʀᴏImage\n"
                            if msg.to in pro["purge"]: md+="🦆⚫ Pᴜʀɢᴇ\n"
                            else: md+="🦆⚪ Pᴜʀɢᴇ\n"
                            if msg.to in pro["pCancl"]: md+="🦆⚫ PʀᴏCancel\n"
                            else: md+="🦆⚪ PʀᴏCancel\n"
                            if msg.to in pro["kickRead"]: md+="🦆⚫ KickRead\n"
                            else: md+="🦆⚪ KickRead\n"
                            if msg.to in pro["kickBaned"]: md+="🦆⚫ KickBaned\n"
                            else: md+="🦆⚪ KickBaned\n"
                            if msg.to in pro["proJS"]: md+="🦆⚫ Pʀᴏjs\n"
                            else: md+="🦆⚪ Pʀᴏjs\n"
                            if msg.to in pro["AJS"]: md+="🦆⚫ Pʀᴏjs2\n"
                            else: md+="🦆⚪ Pʀᴏjs2\n"
                            if msg.to in pro["backupJS"]: md+="🦆⚫ PʀᴏBackupJS\n"
                            else: md+="🦆⚪ PʀᴏBackupJS\n"
                            cl.sendMessage(to, md+"\nDate : "+ datetime.strftime(timeNow,'%Y-%m-%d')+"\nTime  "+ datetime.strftime(timeNow,'%H:%M:%S')+" ")

                        if cmd == "fto":
                          if sender in Creator + admin:
                            cpp["cpp"] = True
                            cl.sendMessage(to,"send picture")
                          
                        if cmd == "projs":
                          if sender in Creator + admin:
                            if msg.to in pro["proJS"] and msg.to in pro["backupJS"] and msg.to in pro["AJS"]:
                                ginfo = cl.getGroup(msg.to)
                                cl.sendMessage(msg.to,"Protection block js on\n"+str(ginfo.name))
                            else:
                                ginfo = cl.getGroup(msg.to)
                                cl.inviteIntoGroup(msg.to, [Emid])
                                cl.inviteIntoGroup(msg.to, [Fmid])
                                pro["proJS"][msg.to] = True
                                pro["backupJS"][msg.to] = True
                                pro["AJS"][msg.to] = True
                                cl.sendMessage(msg.to,"Protection block js on\n"+str(ginfo.name))
                                
                        if cmd == "projs bye":
                          if sender in Creator + admin:
                            if msg.to not in pro["proJS"] and msg.to not in pro["backupJS"] and msg.to not in pro["AJS"]:
                                ginfo = cl.getGroup(msg.to)                            
                                cl.sendMessage(msg.to,"Cancell Projs protection\n"+str(ginfo.name))
                            else:
                                ginfo = cl.getGroup(msg.to)
                                cl.cancelGroupInvitation(msg.to, [Emid])
                                cl.cancelGroupInvitation(msg.to, [Fmid])
                                del pro["proJS"][msg.to]
                                del pro["backupJS"][msg.to]
                                del pro["AJS"][msg.to]
                                cl.sendMessage(msg.to,"Cancell Projs protection\n"+str(ginfo.name))
                              
                        if cmd == "js bye":
                          if sender in Creator + admin:
                                G = cl.getGroup(msg.to)
                                k6.sendMessage(msg.to, "pamit fams "+str(G.name))
                                k5.leaveGroup(msg.to)
                                k6.leaveGroup(msg.to)
                             
                        if cmd == "botlist":
                          if sender in Creator + admin:
                                ma = ""
                                a = 0
                                for m_id in Bots:
                                    a = a + 1
                                    end = '\n'
                                    ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                                cl.sendMessage(msg.to,"🦆Botlist🦆\n\n"+ma+"\n%s Bots" %(str(len(Bots))))
                                
                        if cmd == "admin":
                          if sender in Creator + admin:
                            ma = ""
                            mb = ""
                            a = 0
                            b = 0
                            for m_id in Creator:
                                a = a + 1
                                end = ''
                                ma += "✎ " +str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                            for m_id in admin:
                                b = b + 1
                                end = ''
                                mb += "✎ " +str(b) + ". " +cl.getContact(m_id).displayName + "\n"
                            cl.sendMessage(msg.to,"˃\nOWNER BOT\n"+ma+"\nADMIN BOT\n"+mb+"\n✎ ᴛᴏᴛᴀʟ「%s」ғᴀᴍɪʟʟʏ"%(str(len(Creator)+len(admin))))

                        if cmd == "prolist":
                          if sender in Creator + admin:
                            ma = ""
                            mb = ""
                            mc = ""
                            md = ""
                            me = ""
                            mf = ""
                            a = 0
                            b = 0
                            c = 0
                            d = 0
                            e = 0
                            f = 0
                            gid = pro["proqr"]
                            for group in gid:
                                a = a + 1
                                end = '\n'
                                ma += str(a) + ". " +cl.getGroup(group).name + "\n"
                            gid = pro["proJoin"]
                            for group in gid:
                                b = b + 1
                                end = '\n'
                                mb += str(b) + ". " +cl.getGroup(group).name + "\n"
                            gid = pro["proKick"]
                            for group in gid:
                                c = c + 1
                                end = '\n'
                                mc += str(c) + ". " +cl.getGroup(group).name + "\n"
                            gid = pro["pCancl"]
                            for group in gid:
                                d = d + 1
                                end = '\n'
                                md += str(d) + ". " +cl.getGroup(group).name + "\n"
                            gid = pro["pInvite"]
                            for group in gid:
                                e = e + 1
                                end = '\n'
                                me += str(e) + ". " +cl.getGroup(group).name + "\n"
                            gid = pro["proJS"]
                            for group in gid:
                                f = f + 1
                                end = '\n'
                                mf += str(f) + ". " +cl.getGroup(group).name + "\n"
                            cl.sendMessage(msg.to,"\n\nPʀᴏQR:\n"+ma+"\nPʀᴏJOIN:\n"+mb+"\nPʀᴏKick:\n"+mc+"\nPʀᴏCancel:\n"+md+"\nProINVITE:\n"+me+"\nProJS:\n"+mf+"\n「%s」" %(str(len(pro["proqr"])+len(pro["proJoin"])+len(pro["proKick"])+len(pro["pCancl"])+len(pro["pInvite"])+len(pro["proJS"]))))

                        if cmd == "pro on":
                            if sender in Creator + admin:
                                if msg.to in pro["pname"] and msg.to in pro["pro_name"] and msg.to in pro["picon"] and msg.to in pro["pro_img"] and msg.to in pro["projoin"] and msg.to in pro["proKick"] and msg.to in pro["proqr"] and msg.to in pro["pInvite"] and msg.to in pro["purge"] and msg.to in pro["proJS"] and msg.to in pro["backupJS"] and msg.to in pro["AJS"] and msg.to in pro["pCancl"]:
                                    ginfo = cl.getGroup(msg.to)
                                    cl.sendMessage(msg.to, "Mode Hard Protection active\n"+str(ginfo.name))
                                else:
                                    ginfo = cl.getGroup(msg.to)
                                    pro["pname"][msg.to] = True
                                    pro["picon"][msg.to] = True
                                    pro["proJoin"][msg.to] = True
                                    pro["proKick"][msg.to] = True
                                    pro["proqr"][msg.to] = True
                                    pro["pInvite"][msg.to] = True
                                    pro["purge"][msg.to] = True
                                    pro["proJS"][msg.to] = True
                                    pro["backupJS"][msg.to] = True
                                    pro["AJS"][msg.to] = True
                                    pro["kickBaned"][msg.to] = True
                                    pro["kickRead"][msg.to] = True
                                    pro["pCancl"][msg.to] = True
                                    pro["pro_name"][msg.to] = True
                                    pro["pro_img"][msg.to] = True
                                    cl.sendMessage(msg.to, "Mode Hard Protection active\n"+str(ginfo.name))
                                    
                        if cmd == "pro off":
                            if sender in Creator + admin:
                                if msg.to not in pro["pname"] and msg.to not in pro["pro_name"] and msg.to not in pro["picon"] and msg.to not in pro["pro_img"] and msg.to not in pro["proJoin"] and msg.to not in pro["proKick"] and msg.to not in pro["proqr"] and msg.to not in pro["pInvite"] and msg.to not in pro["purge"] and msg.to not in pro["proJS"] and msg.to not in pro["backupJS"] and msg.to not in pro["AJS"] and msg.to not in pro["pCancl"]:                                    
                                    ginfo = cl.getGroup(msg.to)
                                    cl.sendMessage(msg.to, "Mode Low Protection Deactive\n"+str(ginfo.name))
                                else:
                                    ginfo = cl.getGroup(msg.to)
                                    del pro["pname"][msg.to]
                                    del pro["picon"][msg.to]
                                    del pro["proJoin"][msg.to]
                                    del pro["proKick"][msg.to]
                                    del pro["proqr"][msg.to]
                                    del pro["pInvite"][msg.to]
                                    del pro["purge"][msg.to]
                                    del pro["kickBaned"][msg.to]
                                    del pro["kickRead"][msg.to] 
                                    del pro["pCancl"][msg.to]
                                    del pro["pro_name"][msg.to] 
                                    del pro["pro_img"][msg.to] 
                                    pro["AJS"][msg.to]
                                    pro["proJS"][msg.to]
                                    pro["backupJS"][msg.to]
                                    cl.sendMessage(msg.to, "Mode Low Protection Deactive\n"+str(ginfo.name))
                        
                        elif ("Adminadd " in msg.text):
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            for x in key["MENTIONEES"]:
                                 targets.append(x["M"])
                            for target in targets:
                                    try:
                                        admin.append(target)
                                        f=codecs.open('admin.json','w','utf-8')
                                        json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)
                                        cl.sendMessage(msg.to,"✎ sᴜᴄᴄᴇss ᴀᴅᴅᴇᴅ ᴀᴅᴍɪɴ")
                                    except:
                                        pass

                        elif ("Admindell " in msg.text):
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            for x in key["MENTIONEES"]:
                                 targets.append(x["M"])
                            for target in targets:
                                if target in admin:
                                    try:
                                        admin.remove(target)
                                        f=codecs.open('admin.json','w','utf-8')
                                        json.dump(admin, f, sort_keys=True, indent=4,ensure_ascii=False)     
                                        cl.sendMessage(msg.to,"✎ sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ ᴀᴅᴍɪɴ")
                                    except:
                                        pass
                        
                        elif ("Botadd " in msg.text):
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            for x in key["MENTIONEES"]:
                                 targets.append(x["M"])
                            for target in targets:
                                    try:
                                        Bots.append(target)
                                        f=codecs.open('bots.json','w','utf-8')
                                        json.dump(Bots, f, sort_keys=True, indent=4,ensure_ascii=False)
                                        cl.sendMessage(msg.to,"✎ sᴜᴄᴄᴇss ᴀᴅᴅᴇᴅ Bots")
                                    except:
                                        pass

                        elif ("Botdell " in msg.text):
                            key = eval(msg.contentMetadata["MENTION"])
                            key["MENTIONEES"][0]["M"]
                            targets = []
                            for x in key["MENTIONEES"]:
                                 targets.append(x["M"])
                            for target in targets:
                                if target in Bots:
                                    try:
                                        Bots.remove(target)
                                        f=codecs.open('bots.json','w','utf-8')
                                        json.dump(Bots, f, sort_keys=True, indent=4,ensure_ascii=False)     
                                        cl.sendMessage(msg.to,"✎ sᴜᴄᴄᴇss ᴅᴇʟᴇᴛᴇ Bots")
                                    except:
                                        pass
                        
                        elif cmd == "admin:on" or text.lower() == 'admin:on':
                            if sender in Creator:
                                setting["addadmin"] = True
                                cl.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "admin:off" or text.lower() == 'admin:off':
                            if sender in Creator:
                                setting["delladmin"] = True
                                cl.sendMessage(msg.to,"Kirim kontaknya...")
                        elif cmd == "bot:on" or text.lower() == 'bot:on':
                            if sender in Creator + admin:
                                setting["addbots"] = True
                                cl.sendMessage(msg.to,"Kirim kontaknya...")

                        elif cmd == "bot:off" or text.lower() == 'bot:off':
                            if sender in Creator + admin:
                                setting["dellbots"] = True
                                cl.sendMessage(msg.to,"Kirim kontaknya...")
                                
                        if cmd == "clear":
                          if len(ban["blacklist"]) > 0:
                              cl.sendMessage(to, "Clear [{}] Blacklist ✔️".format(len(ban["blacklist"])))
                              ban["blacklist"] = {}
                              banned()
                          else:
                              cl.sendMessage(to, "No have blacklist")

                        if cmd == "bl":
                          if ban["blacklist"] == {}:
                              cl.sendMessage(msg.to,"Tidak ada blacklist")
                          else:
                              ma = ""
                              a = 0
                              for m_id in ban["blacklist"]:
                                  a = a + 1
                                  end = '\n'
                                  ma += str(a) + ". " +cl.getContact(m_id).displayName + "\n"
                              cl.sendMessage(msg.to,"Blacklist User\n\n"+ma+"\nTotal「%s」Blacklist User" %(str(len(ban["blacklist"]))))

                        if cmd == "jepit":
                          if sender in Creator + admin:
                            try:
                                anggota = [Amid,Bmid,Cmid,Gmid,Dmid]
                                cl.inviteIntoGroup(msg.to, anggota)
                                k1.acceptGroupInvitation(msg.to)
                                k2.acceptGroupInvitation(msg.to)
                                k3.acceptGroupInvitation(msg.to)
                                k4.acceptGroupInvitation(msg.to)
                                k7.acceptGroupInvitation(msg.to)
                            except:
                                cl.sendMessage(msg.to, "Sick") 
                                cl.sendMessage(to, "A")
                                k1.sendMessage(to, "B")
                                k2.sendMessage(to, "C")
                                k3.sendMessage(to, "D")
                                k4.sendMessage(to, "🦆")
                              
                        if cmd == "in": 
                          if sender in Creator + admin:
                            G = cl.getGroup(msg.to)
                            ginfo = cl.getGroup(msg.to)
                            G.preventedJoinByTicket = False
                            cl.updateGroup(G)
                            invsend = 0
                            Ticket = cl.reissueGroupTicket(msg.to)
                            k1.acceptGroupInvitationByTicket(msg.to,Ticket)
                            time.sleep(0.001)
                            k2.acceptGroupInvitationByTicket(msg.to,Ticket)
                            time.sleep(0.001)
                            k3.acceptGroupInvitationByTicket(msg.to,Ticket)
                            time.sleep(0.001)
                            k4.acceptGroupInvitationByTicket(msg.to,Ticket)
                            time.sleep(0.001)
                            k5.acceptGroupInvitationByTicket(msg.to,Ticket)
                            time.sleep(0.001)
                            k6.acceptGroupInvitationByTicket(msg.to,Ticket)
                            time.sleep(0.001)
                            k7.acceptGroupInvitationByTicket(msg.to,Ticket)
                            time.sleep(0.001)
                            G = cl.getGroup(msg.to)
                            G.preventedJoinByTicket = True
                            cl.updateGroup(G)
                            cl.sendMessage(to, "A")
                            k1.sendMessage(to, "B")
                            k2.sendMessage(to, "C")
                            k3.sendMessage(to, "D")
                            k4.sendMessage(to, "E")
                            k7.sendMessage(to, "🦆")

                        if cmd == "xp" or cmd == "spbot":
                          if sender in Creator + admin:
                            get_profile_time_start = time.time()
                            get_profile = cl.getProfile()
                            get_profile_time = time.time() - get_profile_time_start
                            cl.sendMessage(msg.to, "%.10f"%(get_profile_time))
                            get_profile_time_start = time.time()
                            get_profile = k1.getProfile()
                            get_profile_time = time.time() - get_profile_time_start
                            k1.sendMessage(msg.to, "%.10f"%(get_profile_time))
                            get_profile_time_start = time.time()
                            get_profile = k2.getProfile()
                            get_profile_time = time.time() - get_profile_time_start
                            k2.sendMessage(msg.to, "%.10f"%(get_profile_time))
                            get_profile_time_start = time.time()
                            get_profile = k3.getProfile()
                            get_profile_time = time.time() - get_profile_time_start
                            k3.sendMessage(msg.to, "%.10f"%(get_profile_time))
                            get_profile_time_start = time.time()
                            get_profile = k4.getProfile()
                            get_profile_time = time.time() - get_profile_time_start
                            k4.sendMessage(msg.to, "%.10f"%(get_profile_time))
                            get_profile_time_start = time.time()
                            get_profile = k7.getProfile()
                            get_profile_time = time.time() - get_profile_time_start
                            k7.sendMessage(msg.to, "%.10f"%(get_profile_time))
                            
                        if cmd == "out":
                          if sender in Creator + admin:
                            k1.leaveGroup(msg.to)
                            k2.leaveGroup(msg.to)
                            k3.leaveGroup(msg.to)
                            k4.leaveGroup(msg.to)
                            k7.leaveGroup(msg.to)
                            k6.leaveGroup(msg.to)
                            k5.leaveGroup(msg.to)
                        if cmd == "!out":
                          if sender in Creator + admin:
                            cl.leaveGroup(msg.to)

                        if cmd == "jticket:on" or text.lower() == 'jticket on':
                          if sender in Creator + admin:
                            setting["autoJoinTicket"] = True
                            cl.sendMessage(msg.to,"Join ticket allready on")
                        if cmd == "jticket:off" or text.lower() == 'jticket off':
                          if sender in Creator + admin:
                            setting["autoJoinTicket"] = False
                            cl.sendMessage(msg.to,"Join ticket allready off")
                                
                        if "/ti/g/" in msg.text.lower():
                          #if RamSet["selfbot"] == True:
                            if sender in Creator + admin:
                              if setting["autoJoinTicket"] == True:
                                 link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
                                 links = link_re.findall(text)
                                 n_links = []
                                 for l in links:
                                     if l not in n_links:
                                        n_links.append(l)
                                 for ticket_id in n_links:
                                     group = cl.findGroupByTicket(ticket_id)
                                     cl.acceptGroupInvitationByTicket(group.id,ticket_id)
                                     cl.sendMessage(msg.to, "succes into : %s" % str(group.name))

        if msg.contentType == 13:
           if sender in Creator:
            if setting["addbots"] == True:
              if msg.contentMetadata["mid"] in Bots:
                  cl.sendMessage(msg.to,"Already in bot")
                  setting["addbots"] = False
              else:
                  target = msg.contentMetadata["mid"]
                  midd = (target)
                  Bots.append(midd)
                  cl.sendMessage(msg.to, cl.getContact(target).displayName + " has been promoted Bot by " + cl.getContact(msg._from).displayName)
                  setting["addbots"] = False
           if setting["dellbots"] == True:
              if msg.contentMetadata["mid"] in Bots:
                  target = msg.contentMetadata["mid"]
                  midd = (target)
                  Bots.remove(midd)
                  cl.sendMessage(msg.to, cl.getContact(target).displayName + " has been Expel Bot by " + cl.getContact(msg._from).displayName)
                  setting["dellbots"] = False
              else:
                  setting["dellbots"] = True
                  cl.sendMessage(msg.to,"Nothing in bot")
#ADD ADMIN
           if sender in Creator:
            if setting["addadmin"] == True:
              if msg.contentMetadata["mid"] in admin:
                  cl.sendMessage(msg.to,"Already in Admin")
                  setting["addadmin"] = False
              else:
                  target = msg.contentMetadata["mid"]
                  midd = (target)
                  admin.append(midd)
                  cl.sendMessage(msg.to, cl.getContact(target).displayName + " has been promoted Admin by " + cl.getContact(msg._from).displayName)
                  setting["addadmin"] = False
           if setting["delladmin"] == True:
              if msg.contentMetadata["mid"] in admin:
                  target = msg.contentMetadata["mid"]
                  midd = (target)
                  admin.remove(midd)
                  cl.sendMessage(msg.to, cl.getContact(target).displayName + " has been Expel Admin by " + cl.getContact(msg._from).displayName)
                  setting["delladmin"] = False
              else:
                  setting["delladmin"] = True
                  cl.sendMessage(msg.to,"Nothing in admin")
                  
        if msg.contentType == 1:
           if sender in Creator:
              if cpp["cpp"] == True:
                    path = cl.downloadObjectMsg(msg.id)
                    path = k1.downloadObjectMsg(msg.id)
                    path = k2.downloadObjectMsg(msg.id)
                    path = k3.downloadObjectMsg(msg.id)
                    path = k4.downloadObjectMsg(msg.id)
                    path = k5.downloadObjectMsg(msg.id)
                    path = k6.downloadObjectMsg(msg.id)
                    cpp["cpp"] = False
                    cl.updateProfilePicture(path)
                    k1.updateProfilePicture(path)
                    k2.updateProfilePicture(path)
                    k3.updateProfilePicture(path)
                    k4.updateProfilePicture(path)
                    k5.updateProfilePicture(path)
                    k6.updateProfilePicture(path)
                    cl.sendMessage(msg.to, "Done")
                    k1.sendMessage(msg.to, "Done")
                    k2.sendMessage(msg.to, "Done")
                    k3.sendMessage(msg.to, "Done")
                    k4.sendMessage(msg.to, "Done")
                    k5.sendMessage(msg.to, "Done")
                    k6.sendMessage(msg.to, "Done")
                    
async def run():
    while 1:
        try:
            en = cl.poll.fetchOperations(cl.revision, 50)
            for op in en:
                if op.type != 0:
                    cl.revision = max(cl.revision, op.revision)
                    if op.type == 11 or op.type == 122:
                       if op.param2 in ban["blacklist"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t1 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t1.start()
                              t2 = Thread(target=lockqr, args=(op.param1,))
                              t2.start()
                              t3 = Thread(target=black, args=(op.param2,))
                              t3.start()
                       if op.param3 in ban["blacklist"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t4 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t4.start()
                              t4 = Thread(target=lockqr, args=(op.param1,))
                              t5.start()
                              t6 = Thread(target=black, args=(op.param2,))
                              t6.start()
                    if op.type == 11 or op.type == 122:
                       if op.param1 in pro["proqr"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t7 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t7.start()
                              t8 = Thread(target=proqr, args=(op.param1,))
                              t8.start()
                              t9 = Thread(target=black, args=(op.param2,))
                              t9.start()
                       if op.param2 in pro["proqr"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t10 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t10.start()
                              t11 = Thread(target=proqr, args=(op.param1,))
                              t11.start()
                              t12 = Thread(target=black, args=(op.param2,))
                              t12.start()
                    if op.type == 13 or op.type == 124:
                       if op.param1 in pro["pInvite"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t13 = Thread(target=pInvite, args=(op.param1, op.param2))
                              t13.start() 
                              t14 = Thread(target=Rcancel, args=(op.param1, op.param3))
                              t14.start()
                              t15 = Thread(target=black, args=(op.param2,))
                              t15.start()
                       if op.param2 in pro["pInvite"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t16 = Thread(target=pInvite, args=(op.param1, op.param2))
                              t16.start() 
                              t17 = Thread(target=Rcancel, args=(op.param1, op.param3))
                              t17.start()
                              t18 = Thread(target=black, args=(op.param2,))
                              t18.start()
                    if op.type == 13 or op.type == 124:
                       if mid in op.param3:
                           cl.acceptGroupInvitation(op.param1)
                    if op.type == 13 or op.type == 124:
                       if op.param2 in ban["blacklist"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t19 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t19.start() 
                              t20 = Thread(target=Rcancel, args=(op.param1, op.param3))
                              t20.start()
                              t21 = Thread(target=black, args=(op.param2,))
                              t21.start()
                       if op.param3 in ban["blacklist"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t22 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t22.start() 
                              t23 = Thread(target=ccl, args=(op.param1, op.param3))
                              t23.start()
                              t24 = Thread(target=black, args=(op.param2,))
                              t24.start()
                    if op.type == 17 or op.type == 130:
                       if op.param2 in ban["blacklist"]:
                              t25 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t25.start()
                       if op.param3 in ban["blacklist"]:
                              t26 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t26.start()
                    if op.type == 17 or op.type == 130:
                       if op.param1 in pro["proJoin"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t27 = Thread(target=proJoin, args=(op.param1, op.param2))
                              t27.start()
                              t28 = Thread(target=black, args=(op.param2,))
                              t28.start()
                       if op.param2 in pro["proJoin"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t29 = Thread(target=proJoin, args=(op.param1, op.param2))
                              t29.start()
                              t30 = Thread(target=black, args=(op.param2,))
                              t30.start()
                    if op.type == 11 or op.type == 122:
                       if op.param1 in pro["pname"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t31 = Thread(target=pname, args=(op.param1, op.param2))
                              t31.start()
                              t32 = Thread(target=black, args=(op.param2,))
                              t32.start()
                       if op.param1 in pro["pro_name"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t33 = Thread(target=pname, args=(op.param1, op.param2))
                              t33.start()
                              t34 = Thread(target=black, args=(op.param1,))
                              t34.start()
                    if op.type == 11 or op.type == 122:
                       if op.param1 in pro["picon"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t35 = Thread(target=picon, args=(op.param1, op.param2))
                              t35.start()
                              t36 = Thread(target=black, args=(op.param2,))
                              t36.start()
                       if op.param1 in pro["pro_img"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t37 = Thread(target=picon, args=(op.param1, op.param2))
                              t37.start()
                              t38 = Thread(target=black, args=(op.param1,))
                              t38.start()
                    if op.type == 19 or op.type == 133:
                       if op.param3 == Gmid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t39 = Thread(target=black, args=(op.param2,))
                              t39.start() 
                              t40 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t40.start()
                              t41 = Thread(target=backp, args=(op.param1, op.param3))
                              t41.start()
                    if op.type == 19 or op.type == 133:
                       if op.param3 == Amid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t42 = Thread(target=black, args=(op.param2,)) 
                              t42.start() 
                              t43 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t43.start() 
                              t44 = Thread(target=backp1, args=(op.param1, op.param3))
                              t44.start()
                    if op.type == 19 or op.type == 133:
                       if op.param3 == Bmid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t45 = Thread(target=black, args=(op.param2,))
                              t45.start() 
                              t46 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t46.start() 
                              t47 = Thread(target=backp2, args=(op.param1, op.param3))
                              t47.start()
                    if op.type == 19 or op.type == 133:
                       if op.param3 == Cmid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t48 = Thread(target=black, args=(op.param2,))
                              t48.start() 
                              t49 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t49.start()
                              t50 = Thread(target=backp3, args=(op.param1, op.param3))
                              t50.start()
                    if op.type == 19 or op.type == 133:
                       if op.param3 == Dmid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t51 = Thread(target=black, args=(op.param2,))
                              t51.start() 
                              t52 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t52.start()
                              t53 = Thread(target=backp4, args=(op.param1, op.param3))
                              t53.start()
                    if op.type == 19 or op.type == 133:
                       if op.param2 in pro["proKick"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t54 = Thread(target=proKick, args=(op.param1, op.param2))
                              t54.start()
                              t55 = Thread(target=black, args=(op.param2,))
                              t55.start()
                       if op.param3 in pro["proKick"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t56 = Thread(target=proKick, args=(op.param1, op.param2))
                              t56.start()
                              t57 = Thread(target=black, args=(op.param2,))
                              t57.start()
                    if op.type == 32 or op.type == 126:
                       if op.param3 == Emid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t58 = Thread(target=black, args=(op.param2,))
                              t58.start() 
                              t59 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t59.start()
                              t60 = Thread(target=backpAJS, args=(op.param1, op.param3))
                              t60.start()
                    if op.type == 32 or op.type == 126:
                       if op.param3 == Fmid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t61 = Thread(target=black, args=(op.param2,))
                              t61.start() 
                              t62 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t62.start()
                              t63 = Thread(target=backpAJS1, args=(op.param1, op.param3))
                              t63.start()
                    if op.type == 32 or op.type == 126:
                       if op.param3 == Gmid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t64 = Thread(target=black, args=(op.param2,))
                              t64.start() 
                              t65 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t65.start()
                              t66 = Thread(target=backp, args=(op.param1, op.param3))
                              t66.start()
                    if op.type == 32 or op.type == 126:
                       if op.param3 == Amid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t67 = Thread(target=black, args=(op.param2,)) 
                              t67.start() 
                              t68 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t68.start() 
                              t69 = Thread(target=backp1, args=(op.param1, op.param3))
                              t69.start()
                    if op.type == 32 or op.type == 126:
                       if op.param3 == Bmid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t70 = Thread(target=black, args=(op.param2,))
                              t70.start() 
                              t71 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t71.start() 
                              t72 = Thread(target=backp2, args=(op.param1, op.param3))
                              t72.start()
                    if op.type == 32 or op.type == 126:
                       if op.param3 == Cmid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t73 = Thread(target=black, args=(op.param2,))
                              t73.start() 
                              t74 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t74.start()
                              t75 = Thread(target=backp3, args=(op.param1, op.param3))
                              t75.start()
                    if op.type == 32 or op.type == 126:
                       if op.param3 == Dmid:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t76 = Thread(target=black, args=(op.param2,))
                              t76.start() 
                              t77 = Thread(target=Rkick, args=(op.param1, op.param2))
                              t77.start()
                              t78 = Thread(target=backp4, args=(op.param1, op.param3))
                              t78.start()
                    if op.type == 13 or op.type == 17 or op.type == 124:
                       if op.param2 in pro["purge"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                              t79 = Thread(target=proPurge, args=(op.param1, op.param2))
                              t79.start()
                              t80 = Thread(target=black, args=(op.param2,))
                              t80.start()
                       if op.param3 in pro["purge"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                              t81 = Thread(target=proPurge, args=(op.param1, op.param2))
                              t81.start()
                              t82 = Thread(target=black, args=(op.param2,))
                              t82.start()
                    if op.type == 18 or op.type == 13 or op.type == 124:
                       if op.param1 in pro["kickBaned"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t83 = Thread(target=kickBaned, args=(op.param1, op.param2))
                              t83.start()
                              t84 = Thread(target=black, args=(op.param2,))
                              t84.start()
                       if op.param2 in pro["kickBaned"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin: 
                              t85 = Thread(target=kickBaned, args=(op.param1, op.param2))
                              t85.start()
                              t86 = Thread(target=black, args=(op.param2,))
                              t86.start()
                    if op.type == 55 or op.type == 17 or op.type == 130:
                       if op.param2 in pro["kickRead"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                              t87 = Thread(target=kickRead, args=(op.param1, op.param2))
                              t87.start()
                              t88 = Thread(target=black, args=(op.param2,))
                              t88.start()
                       if op.param3 in pro["kickRead"]:
                          if op.param2 not in Bots and op.param2 not in Creator and op.param2 not in admin:
                              t89 = Thread(target=kickRead, args=(op.param1, op.param2))
                              t89.start()
                              t90 = Thread(target=black, args=(op.param2,))
                              t90.start()
                    if op.type == 26:RECEIVED_MESSAGE(op)
                    if op.type == 19 or op.type == 133:NOTIFIED_KICKOUT_FROM_GROUP(op)
                    if op.type == 19 or op.type == 133:NOTIFIED_BACKUP_FROM_GROUP(op)
                    if op.type == 18 or op.type == 124 :bot(op)
                    if op.type == 17 or op.type == 130:NOTIFIED_KICKJOIN_GROUP(op)
                    if op.type == 11 or op.type == 122:NOTIFIED_UPDATE_GROUP(op)
                    if op.type == 13 or op.type == 124:NOTIFIED_INVITE_INTO_GROUP(op)
                    if op.type == 32 or op.type == 126:NOTIFIED_BACKUP_AJS(op)
                    if op.type == 32 or op.type == 126:NOTIFIED_REJECT_GROUP_INVITATION(op)
        except Exception as e:
          e = traceback.format_exc()
          if "EOFError" in e:
              pass
          elif "log_out" in e.lower():
              python = sys.executable
              os.execl(python, python, *sys.argv)
          elif "ShouldSyncException" in e:
              python3 = sys.executable
              os.execl(python3, python3, *sys.argv)
          elif "TalkException(code=8, reason='LOG_OUT', parameterMap=None)" in e:
              python = sys.executable
              os.execl(python, python, *sys.argv)
          elif "TalkException(code=20, reason='[UNCAUGHT_INTERNAL_ERROR] [UNCAUGHT_INTERNAL_ERROR] Login from secondary user blocked by userHash + clientType 8cb91561b450b38ccf0119fc4f5e37a3MA', parameterMap=None)" in e:
              backupData()
              python3 = sys.executable
              os.execl(python3, python3, *sys.argv)
          else:
              traceback.print_exc()
if __name__ == '__main__':
    threading.Thread(target=event_loop.run_until_complete(run())).start()
print ("===========[ BACKUP BOTS ]===========")
thread = threading.Thread(target=botrun)
thread.start()
