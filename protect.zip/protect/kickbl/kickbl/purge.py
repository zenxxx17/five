def purge(self,to):
    try:
        group = self.client.getGroup(to)
        members = [o.mid for o in group.members]
        ban = set(members).intersection(self.setting["blacklist"])
        cms = "purge.js gid={} token={}".format(to, self.client.authToken)
        for y in ban:
            cms += " uid={}".format(y)
        success = execute_js(cms)
    except:
        e = traceback.format_exc()
        if "code=35" in e:
            print("Kick banned")